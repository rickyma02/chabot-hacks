
#include <iostream>
#include <string>
#include <fstream>
#include <iomanip>
using namespace std;
int main()
{
    string physical[365];
    string creative[5];
    string intellectual[5];
    string culinary[5];
    string entertainment[5];
    string nature[5];
    string diy[5];
    string social[5];
    string travel[5];
    string mindfulness[5];
    string collecting[5];
    string Data[207];
    physical[0] ="bruh";
    ifstream infile("Hobbies.txt");
    if (!infile){
        cout<<"Couldn't open file."<<endl;
    }
    else{
        for(int j = 0;j<207;j++){
       getline(infile,Data[j]);
        }
        int i = 0;

        while(Data[i].length()>1){
            physical[i] = Data[i];
            cout<<physical[i]<<endl;
            i++;
        }
        while(Data[i].length()>1){
            physical[i] = Data[i];
            cout<<physical[i]<<endl;
            i++;
        }
    }
    return 0;
       }

