#include <fstream>
#include <iomanip>
#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
using namespace std;
int main() {
  // VARIABLES
  int physical, creative, intellectual, culinary, entertainment, nature, diy,
      social, travel, mindfulness, collecting;
  int totalLength = 0;
  int totalLengthC = 0;
  //int totalLengthW = 0;
  // HOBBIES
  string physicalA[189];
  string creativeA[189];
  string intellectualA[189];
  string culinaryA[189];
  string entertainmentA[189];
  string natureA[189];
  string diyA[189];
  string socialA[189];
  string travelA[189];
  string mindfulnessA[189];
  string collectingA[189];
  string data[189];
  // CONTENT CREATORS
  string physicalC[121];
  string creativeC[121];
  string intellectualC[121];
  string culinaryC[121];
  string entertainmentC[121];
  string natureC[121];
  string diyC[121];
  string socialC[121];
  string travelC[121];
  string mindfulnessC[121];
  string collectingC[121];
  string dataC[121];

  int physicalCL = 0;
  int creativeCL = 0;
  int intellectualCL = 0;
  int culinaryCL = 0;
  int entertainmentCL = 0;
  int natureCL = 0;
  int diyCL = 0;
  int socialCL = 0;
  int travelCL = 0;
  int mindfulnessCL = 0;
  int collectingCL = 0;

  int physicalAL = 0;
  int creativeAL = 0;
  int intellectualAL = 0;
  int culinaryAL = 0;
  int entertainmentAL = 0;
  int natureAL = 0;
  int diyAL = 0;
  int socialAL = 0;
  int travelAL = 0;
  int mindfulnessAL = 0;
  int collectingAL = 0;
  
  char toggle = 'y';
  srand(time(0));

  // QUESTIONAIRE
  cout << "Would you be interested in physically-demanding activies? (1 for "
          "YES, 0 for NO): ";
  cin >> physical;
  cout << endl
       << "Would you be interested in more creative pursuits? (1 for YES, 0 "
          "for NO): ";
  cin >> creative;
  cout << endl
       << "Would you be interested in learning or other intellectual hobbies? "
          "(1 for YES, 0 for NO): ";
  cin >> intellectual;
  cout << endl
       << "Would you be interested in culinary arts? (1 for YES, 0 for NO): ";
  cin >> culinary;
  cout << endl
       << "Would you be interested in playing games or other forms of "
          "entertainment? (1 for YES, 0 for NO): ";
  cin >> entertainment;
  cout << endl
       << "Would you be interested in hobbies involving nature? (1 for YES, 0 "
          "for NO): ";
  cin >> nature;
  cout << endl
       << "Would you be interested in DIY or home improvement? (1 for YES, 0 "
          "for NO): ";
  cin >> diy;
  cout << endl
       << "Would you be interested in being social and involved with your "
          "local community? (1 for YES, 0 for NO): ";
  cin >> social;
  cout << endl
       << "Would you be interested in travelling and exploring new places? (1 "
          "for YES, 0 for NO): ";
  cin >> travel;
  cout << endl
       << "Would you be interested in practicing mindfulness through your "
          "hobbies? (1 for YES, 0 for NO): ";
  cin >> mindfulness;
  cout << endl
       << "Would you be interested in building and maintaining a collection of "
          "something? (1 for YES, 0 for NO): ";
  cin >> collecting;
  cout << endl << endl << endl;

  // CREATING ARRAYS
  // Each category is seperated by an empty line, and lacks a header to describe
  // the category. Data array must be formatted for code to work
  // HOBBIES
  ifstream infile("Hobbies.txt");
  if (!infile) {
    cout << "Couldn't open file." << endl;
  } else {
    for (int i = 0; i < 207; i++) {
      getline(infile, data[i]);
    }
    int j = 0;
    while (data[j].length() > 1) {
      physicalA[j] = data[j];
      j++;
    }
    j++;
    while (data[j].length() > 1) {
      creativeA[j] = data[j];
      j++;
    }
    j++;
    while (data[j].length() > 1) {
      intellectualA[j] = data[j];
      j++;
    }
    j++;
    while (data[j].length() > 1) {
      culinaryA[j] = data[j];
      j++;
    }
    j++;
    while (data[j].length() > 1) {
      entertainmentA[j] = data[j];
      j++;
    }
    j++;
    while (data[j].length() > 1) {
      natureA[j] = data[j];
      j++;
    }
    j++;
    while (data[j].length() > 1) {
      diyA[j] = data[j];
      j++;
    }
    j++;
    while (data[j].length() > 1) {
      socialA[j] = data[j];
      j++;
    }
    j++;
    while (data[j].length() > 1) {
      travelA[j] = data[j];
      j++;
    }
    j++;
    while (data[j].length() > 1) {
      mindfulnessA[j] = data[j];
      j++;
    }
    j++;
    while (data[j].length() > 1) {
      collectingA[j] = data[j];
      j++;
    }
    j++;
  }
  // CONTENT CREATORS
  ifstream infileC("Content.txt");
  if (!infileC) {
    cout << "Couldn't open file." << endl;
  } else {
    for (int i = 0; i < 207; i++) {
      getline(infileC, dataC[i]);
    }
    int j = 0;
    while (dataC[j].length() > 1) {
      physicalC[j] = dataC[j];
      physicalCL++;
      j++;
    }
    j++;
    while (dataC[j].length() > 1) {
      creativeC[j] = dataC[j];
      creativeCL++;
      j++;
    }
    j++;
    while (dataC[j].length() > 1) {
      intellectualC[j] = dataC[j];
      intellectualCL++;
      j++;
    }
    j++;
    while (dataC[j].length() > 1) {
      culinaryC[j] = dataC[j];
      culinaryCL++;
      j++;
    }
    j++;
    while (dataC[j].length() > 1) {
      entertainmentC[j] = dataC[j];
      entertainmentCL++;
      j++;
    }
    j++;
    while (dataC[j].length() > 1) {
      natureC[j] = dataC[j];
      natureCL++;
      j++;
    }
    j++;
    while (dataC[j].length() > 1) {
      diyC[j] = dataC[j];
      diyCL++;
      j++;
    }
    j++;
    while (dataC[j].length() > 1) {
      socialC[j] = dataC[j];
      socialCL++;
      j++;
    }
    j++;
    while (dataC[j].length() > 1) {
      travelC[j] = dataC[j];
      travelCL++;
      j++;
    }
    j++;
    while (dataC[j].length() > 1) {
      mindfulnessC[j] = dataC[j];
      mindfulnessCL++;
      j++;
    }
    j++;
    while (dataC[j].length() > 1) {
      collectingC[j] = dataC[j];
      collectingCL++;
      j++;
    }
    j++;
  }
  string physicalCA[physicalCL];
  string creativeCA[creativeCL];
  string intellectualCA[intellectualCL];
  string culinaryCA[culinaryCL];
  string entertainmentCA[entertainmentCL];
  string natureCA[natureCL];
  string diyCA[diyCL];
  string socialCA[socialCL];
  string travelCA[travelCL];
  string mindfulnessCA[mindfulnessCL];
  string collectingCA[collectingCL];

  // FORMATTING ARRAYS TO BE COMBINED
  // HOBBIES
  if (physical == 1) {
    for (int i = 0; i < (end(physicalA) - begin(physicalA)); i++) {
      if (physicalA[i].length() > 1) {
        totalLength++;
        physicalAL++;
      }
    }
  }
  if (creative == 1) {
    for (int i = 0; i < (end(creativeA) - begin(creativeA)); i++) {
      if (creativeA[i].length() > 1) {
        totalLength++;
        creativeAL++;
      }
    }
  }
  if (intellectual == 1) {
    for (int i = 0; i < (end(intellectualA) - begin(intellectualA)); i++) {
      if (intellectualA[i].length() > 1) {
        totalLength++;
        intellectualAL++;
      }
    }
  }
  if (culinary == 1) {
    for (int i = 0; i < (end(culinaryA) - begin(culinaryA)); i++) {
      if (culinaryA[i].length() > 1) {
        totalLength++;
        culinaryAL++;
      }
    }
  }
  if (entertainment == 1) {
    for (int i = 0; i < (end(entertainmentA) - begin(entertainmentA)); i++) {
      if (entertainmentA[i].length() > 1) {
        totalLength++;
        entertainmentAL++;
      }
    }
  }
  if (nature == 1) {
    for (int i = 0; i < (end(natureA) - begin(natureA)); i++) {
      if (natureA[i].length() > 1) {
        totalLength++;
        natureAL++;
      }
    }
  }
  if (diy == 1) {
    for (int i = 0; i < (end(diyA) - begin(diyA)); i++) {
      if (diyA[i].length() > 1) {
        totalLength++;
        diyAL++;
      }
    }
  }
  if (social == 1) {
    for (int i = 0; i < (end(socialA) - begin(socialA)); i++) {
      if (socialA[i].length() > 1) {
        totalLength++;
        socialAL++;
      }
    }
  }
  if (travel == 1) {
    for (int i = 0; i < (end(travelA) - begin(travelA)); i++) {
      if (travelA[i].length() > 1) {
        totalLength++;
        travelAL++;
      }
    }
  }
  if (mindfulness == 1) {
    for (int i = 0; i < (end(mindfulnessA) - begin(mindfulnessA)); i++) {
      if (mindfulnessA[i].length() > 1) {
        totalLength++;
        mindfulnessAL++;
      }
    }
  }
  if (collecting == 1) {
    for (int i = 0; i < (end(collectingA) - begin(collectingA)); i++) {
      if (collectingA[i].length() > 1) {
        totalLength++;
        collectingAL++;
      }
    }
  }
  string total[totalLength];
  // CONTENT CREATORS
  if (physical == 1) {
    int l = 0;
    for (int i = 0; i < (end(physicalC) - begin(physicalC)); i++) {
      if (physicalC[i].length() > 1) {
        physicalCA[l] = physicalC[i];
        l++;
      }
    }
  }
  if (creative == 1) {
    int l = 0;
    for (int i = 0; i < (end(creativeC) - begin(creativeC)); i++) {
      if (creativeC[i].length() > 1) {
      creativeCA[l] = creativeC[i];
      l++;      
      }
    }
  }
  if (intellectual == 1) {
    int l = 0;
    for (int i = 0; i < (end(intellectualC) - begin(intellectualC)); i++) {
      if (intellectualC[i].length() > 1) {
        intellectualCA[l] = intellectualC[i];
        l++;
      }
    }
  }
  if (culinary == 1) {
    int l = 0;
    for (int i = 0; i < (end(culinaryC) - begin(culinaryC)); i++) {
      if (culinaryC[i].length() > 1) {
      culinaryCA[l] = culinaryC[i];
      l++;      
      }
    }
  }
  if (entertainment == 1) {
    int l = 0;
    for (int i = 0; i < (end(entertainmentC) - begin(entertainmentC)); i++) {
      if (entertainmentC[i].length() > 1) {
       entertainmentCA[l] = entertainmentC[i];
        l++;
      }
    }
  }
  if (nature == 1) {
    int l = 0;
    for (int i = 0; i < (end(natureC) - begin(natureC)); i++) {
      if (natureC[i].length() > 1) {
        natureCA[l] = natureC[i];
        l++;
      }
    }
  }
  if (diy == 1) {
    int l = 0;
    for (int i = 0; i < (end(diyC) - begin(diyC)); i++) {
      if (diyC[i].length() > 1) {
        diyCA[l] = diyC[i];
        l++;
      }
    }
  }
  if (social == 1) {
    int l = 0;
    for (int i = 0; i < (end(socialC) - begin(socialC)); i++) {
      if (socialC[i].length() > 1) {
        socialCA[l] = socialC[i];
        l++;
      }
    }
  }
  if (travel == 1) {
    int l = 0;
    for (int i = 0; i < (end(travelC) - begin(travelC)); i++) {
      if (travelC[i].length() > 1) {
       travelCA[l] = travelC[i];
        l++;
      }
    }
  }
  if (mindfulness == 1) {
    int l = 0;
    for (int i = 0; i < (end(mindfulnessC) - begin(mindfulnessC)); i++) {
      if (mindfulnessC[i].length() > 1) {
       mindfulnessCA[l] = mindfulnessC[i];
        l++;
      }
    }
  }
  if (collecting == 1) {
    int l = 0;
    for (int i = 0; i < (end(collectingC) - begin(collectingC)); i++) {
      if (collectingC[i].length() > 1) {
        collectingCA[l] = collectingC[i];
        l++;
      }
    }
  }
  string totalC[totalLengthC];

  // COMBINING ARRAYS
  // HOBBIES
  int k = 0;
  if (physical == 1) {
    for (int i = 0; i < (end(physicalA) - begin(physicalA)); i++) {
      if (physicalA[i].length() > 1) {
        total[k] = physicalA[i];
        k++;
      }
    }
  }
  if (creative == 1) {
    for (int i = 0; i < (end(creativeA) - begin(creativeA)); i++) {
      if (creativeA[i].length() > 1) {
        total[k] = creativeA[i];
        k++;
      }
    }
  }
  if (intellectual == 1) {
    for (int i = 0; i < (end(intellectualA) - begin(intellectualA)); i++) {
      if (intellectualA[i].length() > 1) {
        total[k] = intellectualA[i];
        k++;
      }
    }
  }
  if (culinary == 1) {
    for (int i = 0; i < (end(culinaryA) - begin(culinaryA)); i++) {
      if (culinaryA[i].length() > 1) {
        total[k] = culinaryA[i];
        k++;
      }
    }
  }
  if (entertainment == 1) {
    for (int i = 0; i < (end(entertainmentA) - begin(entertainmentA)); i++) {
      if (entertainmentA[i].length() > 1) {
        total[k] = entertainmentA[i];
        k++;
      }
    }
  }
  if (nature == 1) {
    for (int i = 0; i < (end(natureA) - begin(natureA)); i++) {
      if (natureA[i].length() > 1) {
        total[k] = natureA[i];
        k++;
      }
    }
  }
  if (diy == 1) {
    for (int i = 0; i < (end(diyA) - begin(diyA)); i++) {
      if (diyA[i].length() > 1) {
        total[k] = diyA[i];
        k++;
      }
    }
  }
  if (social == 1) {
    for (int i = 0; i < (end(socialA) - begin(socialA)); i++) {
      if (socialA[i].length() > 1) {
        total[k] = socialA[i];
        k++;
      }
    }
  }
  if (travel == 1) {
    for (int i = 0; i < (end(travelA) - begin(travelA)); i++) {
      if (travelA[i].length() > 1) {
        total[k] = travelA[i];
        k++;
      }
    }
  }
  if (mindfulness == 1) {
    for (int i = 0; i < (end(mindfulnessA) - begin(mindfulnessA)); i++) {
      if (mindfulnessA[i].length() > 1) {
        total[k] = mindfulnessA[i];
        k++;
      }
    }
  }
  if (collecting == 1) {
    for (int i = 0; i < (end(collectingA) - begin(collectingA)); i++) {
      if (collectingA[i].length() > 1) {
        total[k] = collectingA[i];
        k++;
      }
    }
  }
int L1 = physicalAL;
int L2 = L1 + creativeAL;
int L3 = L2 + intellectualAL;
int L4 = L3 + culinaryAL;
int L5 = L4 + entertainmentAL;
int L6 = L5 + natureAL;
int L7 = L6 + diyAL;
int L8 = L7 + socialAL;
int L9 = L8 + travelAL;
int L10 = L9 + mindfulnessAL;
int L11 = L10 + collectingAL;

  //WHILE LOOP TO DISPLAY
  while((toggle == 'y')||(toggle == 'Y')){
    int random = rand() % totalLength;
    cout<<"Here is a hobby you could try: "<<total[random]<<endl;
    cout<<"Based on your interests, here is a content creator you might like: ";
    if((random>=0)&&(random<L1)){
      int randomC = rand() % physicalCL;
      cout<<physicalCA[randomC]<<endl;
    }
    else if((random>=L1)&&(random<L2)){
      int randomC = rand() % creativeCL;
      cout<<creativeCA[randomC]<<endl;
      }
    else if((random>=L2)&&(random<L3)){
      int randomC = rand() % intellectualCL;
      cout<<intellectualCA[randomC]<<endl;
    }
    else if((random>=L3)&&(random<L4)){
      int randomC = rand() % culinaryCL;
      cout<<culinaryCA[randomC]<<endl;
    }
    else if((random>=L4)&&(random<L5)){
      int randomC = rand() % entertainmentCL;
      cout<<entertainmentCA[randomC]<<endl;
    }
    else if((random>=L5)&&(random<L6)){
      int randomC = rand() %natureCL;
      cout<<natureCA[randomC]<<endl;
    }
    else if((random>=L6)&&(random<L7)){
      int randomC = rand() % diyCL;
      cout<<diyCA[randomC]<<endl;
    }
    else if((random>=L7)&&(random<L8)){
      int randomC = rand() % socialCL;
      cout<<socialCA[randomC]<<endl;
    }
    else if((random>=L8)&&(random<L9)){
      int randomC = rand() % travelCL;
      cout<<travelCA[randomC]<<endl;
    }
    else if((random>=L9)&&(random<L10)){
      int randomC = rand() % mindfulnessCL;
      cout<<mindfulnessCA[randomC]<<endl;
    }
    else if((random>=L10)&&(random<L11)){
      int randomC = rand() % collectingCL;
      cout<<collectingCA[randomC]<<endl;
    }
    cout<<endl;
    cout<<"Would you like another hobby? (y/n): ";
    cin>>toggle;
    cout<<endl;
  }
  cout<<endl<<endl<<"We hope you enjoy your new hobby!";
  return 0;
}